package com.example.andres.dailyselfie.activities;

import android.os.Bundle;

import com.example.andres.dailyselfie.fragments.MainFragment;
import com.example.andres.dailyselfie.support.TopLevelActivity;


public class MainActivity extends TopLevelActivity
{
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentFragment(MainFragment.newInstance());
    }
}
